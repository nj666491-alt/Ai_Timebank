import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";

export type FeedbackCategory = "suggestion" | "bug" | "review" | "ui" | "other";

export const FEEDBACK_CATEGORIES: FeedbackCategory[] = [
  "suggestion",
  "bug",
  "review",
  "ui",
  "other",
];

export interface FeedbackEntry {
  id: string;
  rating: number;
  category: FeedbackCategory;
  message: string;
  name: string;
  createdAt: number;
}

interface FeedbackContextType {
  feedbackList: FeedbackEntry[];
  addFeedback: (entry: Omit<FeedbackEntry, "id" | "createdAt">) => Promise<void>;
  deleteFeedback: (id: string) => void;
}

const FeedbackContext = createContext<FeedbackContextType | null>(null);

function genId() {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

export function FeedbackProvider({ children }: { children: React.ReactNode }) {
  const [feedbackList, setFeedbackList] = useState<FeedbackEntry[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem("feedbackList")
      .then((raw) => {
        if (raw) setFeedbackList(JSON.parse(raw));
      })
      .finally(() => setLoaded(true));
  }, []);

  useEffect(() => {
    if (loaded) {
      AsyncStorage.setItem("feedbackList", JSON.stringify(feedbackList));
    }
  }, [feedbackList, loaded]);

  const addFeedback = useCallback(
    async (entry: Omit<FeedbackEntry, "id" | "createdAt">) => {
      const full: FeedbackEntry = {
        ...entry,
        id: genId(),
        createdAt: Date.now(),
      };
      setFeedbackList((prev) => [...prev, full]);
    },
    []
  );

  const deleteFeedback = useCallback((id: string) => {
    setFeedbackList((prev) => prev.filter((f) => f.id !== id));
  }, []);

  return (
    <FeedbackContext.Provider value={{ feedbackList, addFeedback, deleteFeedback }}>
      {children}
    </FeedbackContext.Provider>
  );
}

export function useFeedback() {
  const ctx = useContext(FeedbackContext);
  if (!ctx) throw new Error("useFeedback must be used within FeedbackProvider");
  return ctx;
}
