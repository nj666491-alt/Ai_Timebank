import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";

export interface Platform {
  id: string;
  name: string;
  icon: string;
  color: string;
  dailyLimitMinutes: number;
  enabled: boolean;
}

export interface UsageRecord {
  id: string;
  platformId: string;
  date: string;
  minutesUsed: number;
  minutesBorrowed: number;
}

export interface BorrowRecord {
  id: string;
  platformId: string;
  borrowDate: string;
  repayDate: string;
  minutesBorrowed: number;
  repaid: boolean;
}

export interface ActiveSession {
  platformId: string;
  startTime: number;
}

interface AppContextType {
  platforms: Platform[];
  usageRecords: UsageRecord[];
  borrowRecords: BorrowRecord[];
  activeSession: ActiveSession | null;
  elapsedSeconds: number;
  startSession: (platformId: string) => void;
  stopSession: () => void;
  borrowTime: (platformId: string, minutes: number) => Promise<boolean>;
  getTodayUsage: (platformId: string) => UsageRecord | null;
  getTomorrowDeduction: (platformId: string) => number;
  getRemainingMinutes: (platformId: string) => number;
  updatePlatform: (platform: Platform) => void;
  addPlatform: (platform: Platform) => void;
  removePlatform: (id: string) => void;
  clearAllData: () => void;
}

const DEFAULT_PLATFORMS: Platform[] = [
  { id: "chatgpt", name: "ChatGPT", icon: "message-circle", color: "#10a37f", dailyLimitMinutes: 40, enabled: true },
  { id: "claude", name: "Claude", icon: "cpu", color: "#d97706", dailyLimitMinutes: 60, enabled: true },
  { id: "gemini", name: "Gemini", icon: "zap", color: "#4285f4", dailyLimitMinutes: 90, enabled: true },
  { id: "perplexity", name: "Perplexity", icon: "search", color: "#7c3aed", dailyLimitMinutes: 30, enabled: true },
  { id: "copilot", name: "Copilot", icon: "code", color: "#0078d4", dailyLimitMinutes: 45, enabled: false },
];

const AppContext = createContext<AppContextType | null>(null);

function todayStr() {
  return new Date().toISOString().split("T")[0];
}

function tomorrowStr() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  return d.toISOString().split("T")[0];
}

function genId() {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [platforms, setPlatforms] = useState<Platform[]>(DEFAULT_PLATFORMS);
  const [usageRecords, setUsageRecords] = useState<UsageRecord[]>([]);
  const [borrowRecords, setBorrowRecords] = useState<BorrowRecord[]>([]);
  const [activeSession, setActiveSession] = useState<ActiveSession | null>(null);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [p, u, b, s] = await Promise.all([
        AsyncStorage.getItem("platforms"),
        AsyncStorage.getItem("usageRecords"),
        AsyncStorage.getItem("borrowRecords"),
        AsyncStorage.getItem("activeSession"),
      ]);
      if (p) setPlatforms(JSON.parse(p));
      if (u) setUsageRecords(JSON.parse(u));
      if (b) setBorrowRecords(JSON.parse(b));
      if (s) {
        const session = JSON.parse(s) as ActiveSession;
        setActiveSession(session);
        setElapsedSeconds(Math.floor((Date.now() - session.startTime) / 1000));
      }
    } catch {}
    setLoaded(true);
  };

  useEffect(() => {
    if (loaded) {
      AsyncStorage.setItem("platforms", JSON.stringify(platforms));
    }
  }, [platforms, loaded]);

  useEffect(() => {
    if (loaded) {
      AsyncStorage.setItem("usageRecords", JSON.stringify(usageRecords));
    }
  }, [usageRecords, loaded]);

  useEffect(() => {
    if (loaded) {
      AsyncStorage.setItem("borrowRecords", JSON.stringify(borrowRecords));
    }
  }, [borrowRecords, loaded]);

  useEffect(() => {
    if (activeSession) {
      AsyncStorage.setItem("activeSession", JSON.stringify(activeSession));
      intervalRef.current = setInterval(() => {
        setElapsedSeconds(Math.floor((Date.now() - activeSession.startTime) / 1000));
      }, 1000);
    } else {
      AsyncStorage.removeItem("activeSession");
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [activeSession]);

  const getTodayUsage = useCallback(
    (platformId: string): UsageRecord | null => {
      const today = todayStr();
      return usageRecords.find((r) => r.platformId === platformId && r.date === today) ?? null;
    },
    [usageRecords]
  );

  const getTomorrowDeduction = useCallback(
    (platformId: string): number => {
      const tomorrow = tomorrowStr();
      const borrows = borrowRecords.filter(
        (b) => b.platformId === platformId && b.repayDate === tomorrow && !b.repaid
      );
      return borrows.reduce((sum, b) => sum + b.minutesBorrowed, 0);
    },
    [borrowRecords]
  );

  const getRemainingMinutes = useCallback(
    (platformId: string): number => {
      const platform = platforms.find((p) => p.id === platformId);
      if (!platform) return 0;
      const todayRecord = getTodayUsage(platformId);
      const used = todayRecord ? todayRecord.minutesUsed : 0;
      const borrowed = todayRecord ? todayRecord.minutesBorrowed : 0;
      return platform.dailyLimitMinutes + borrowed - used;
    },
    [platforms, getTodayUsage]
  );

  const startSession = useCallback(
    (platformId: string) => {
      if (activeSession) {
        stopSession();
      }
      const session: ActiveSession = { platformId, startTime: Date.now() };
      setActiveSession(session);
      setElapsedSeconds(0);
    },
    [activeSession]
  );

  const stopSession = useCallback(() => {
    if (!activeSession) return;
    const minutesUsed = Math.ceil(elapsedSeconds / 60);
    if (minutesUsed > 0) {
      const today = todayStr();
      setUsageRecords((prev) => {
        const existing = prev.find(
          (r) => r.platformId === activeSession.platformId && r.date === today
        );
        if (existing) {
          return prev.map((r) =>
            r.id === existing.id
              ? { ...r, minutesUsed: r.minutesUsed + minutesUsed }
              : r
          );
        }
        return [
          ...prev,
          {
            id: genId(),
            platformId: activeSession.platformId,
            date: today,
            minutesUsed,
            minutesBorrowed: 0,
          },
        ];
      });
    }
    setActiveSession(null);
    setElapsedSeconds(0);
  }, [activeSession, elapsedSeconds]);

  const borrowTime = useCallback(
    async (platformId: string, minutes: number): Promise<boolean> => {
      const platform = platforms.find((p) => p.id === platformId);
      if (!platform) return false;
      const maxBorrow = Math.floor(platform.dailyLimitMinutes * 0.5);
      const today = todayStr();
      const existing = usageRecords.find((r) => r.platformId === platformId && r.date === today);
      const alreadyBorrowed = existing?.minutesBorrowed ?? 0;
      if (alreadyBorrowed + minutes > maxBorrow) return false;

      const borrow: BorrowRecord = {
        id: genId(),
        platformId,
        borrowDate: today,
        repayDate: tomorrowStr(),
        minutesBorrowed: minutes,
        repaid: false,
      };
      setBorrowRecords((prev) => [...prev, borrow]);

      setUsageRecords((prev) => {
        const existing = prev.find((r) => r.platformId === platformId && r.date === today);
        if (existing) {
          return prev.map((r) =>
            r.id === existing.id
              ? { ...r, minutesBorrowed: r.minutesBorrowed + minutes }
              : r
          );
        }
        return [
          ...prev,
          { id: genId(), platformId, date: today, minutesUsed: 0, minutesBorrowed: minutes },
        ];
      });
      return true;
    },
    [platforms, usageRecords]
  );

  const updatePlatform = useCallback((platform: Platform) => {
    setPlatforms((prev) => prev.map((p) => (p.id === platform.id ? platform : p)));
  }, []);

  const addPlatform = useCallback((platform: Platform) => {
    setPlatforms((prev) => [...prev, platform]);
  }, []);

  const removePlatform = useCallback((id: string) => {
    setPlatforms((prev) => prev.filter((p) => p.id !== id));
  }, []);

  const clearAllData = useCallback(async () => {
    setUsageRecords([]);
    setBorrowRecords([]);
    setActiveSession(null);
    await AsyncStorage.multiRemove(["usageRecords", "borrowRecords", "activeSession"]);
  }, []);

  return (
    <AppContext.Provider
      value={{
        platforms,
        usageRecords,
        borrowRecords,
        activeSession,
        elapsedSeconds,
        startSession,
        stopSession,
        borrowTime,
        getTodayUsage,
        getTomorrowDeduction,
        getRemainingMinutes,
        updatePlatform,
        addPlatform,
        removePlatform,
        clearAllData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
