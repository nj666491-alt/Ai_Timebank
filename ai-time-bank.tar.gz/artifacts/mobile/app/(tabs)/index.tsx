import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Platform,
  useColorScheme,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { useApp, Platform as AIPlatform } from "@/context/AppContext";
import { TimeRing } from "@/components/TimeRing";
import { BorrowModal } from "@/components/BorrowModal";

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";
  const { platforms, activeSession, elapsedSeconds, getTodayUsage, getRemainingMinutes, getTomorrowDeduction, borrowRecords, usageRecords } = useApp();
  const [borrowTarget, setBorrowTarget] = useState<AIPlatform | null>(null);

  const enabledPlatforms = platforms.filter((p) => p.enabled);

  const totalLimitMinutes = enabledPlatforms.reduce((s, p) => s + p.dailyLimitMinutes, 0);
  const totalUsedMinutes = enabledPlatforms.reduce((s, p) => {
    const rec = getTodayUsage(p.id);
    const isActive = activeSession?.platformId === p.id;
    return s + (rec?.minutesUsed ?? 0) + (isActive ? Math.floor(elapsedSeconds / 60) : 0);
  }, 0);
  const totalBorrowedMinutes = enabledPlatforms.reduce((s, p) => {
    const rec = getTodayUsage(p.id);
    return s + (rec?.minutesBorrowed ?? 0);
  }, 0);
  const totalTomorrowDeduction = enabledPlatforms.reduce((s, p) => s + getTomorrowDeduction(p.id), 0);

  const today = new Date().toISOString().split("T")[0];
  const todayBorrows = borrowRecords.filter((b) => b.borrowDate === today);

  const topPlatform = activeSession
    ? enabledPlatforms.find((p) => p.id === activeSession.platformId)
    : null;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: Platform.OS === "web" ? 67 + 16 : insets.top + 16,
            paddingBottom: Platform.OS === "web" ? 34 + 84 : insets.bottom + 84,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Hero */}
        <View style={styles.heroRow}>
          <View>
            <Text style={[styles.greeting, { color: colors.mutedForeground }]}>
              {getGreeting()}
            </Text>
            <Text style={[styles.heroTitle, { color: colors.foreground }]}>AI Time Bank</Text>
          </View>
          <View style={[styles.dateChip, { backgroundColor: colors.secondary }]}>
            <Text style={[styles.dateText, { color: colors.primary }]}>
              {new Date().toLocaleDateString("en-US", { month: "short", day: "numeric" })}
            </Text>
          </View>
        </View>

        {/* Active session banner */}
        {topPlatform && (
          <View style={[styles.activeBanner, { backgroundColor: topPlatform.color + "18", borderColor: topPlatform.color + "44" }]}>
            <View style={[styles.activeDot, { backgroundColor: topPlatform.color }]} />
            <Text style={[styles.activeName, { color: topPlatform.color }]}>
              {topPlatform.name}
            </Text>
            <Text style={[styles.activeTime, { color: topPlatform.color }]}>
              {formatSeconds(elapsedSeconds)}
            </Text>
          </View>
        )}

        {/* Big ring */}
        <View style={[styles.ringCard, { backgroundColor: isDark ? colors.card : colors.surface, borderColor: colors.border }]}>
          <TimeRing
            used={totalUsedMinutes}
            total={totalLimitMinutes + totalBorrowedMinutes}
            borrowed={totalBorrowedMinutes}
            size={160}
            color={colors.primary}
            sublabel="remaining"
          />
          <View style={styles.ringStats}>
            <RingStat label="Used" value={`${totalUsedMinutes}m`} color={colors.primary} />
            <RingStat label="Limit" value={`${totalLimitMinutes}m`} color={colors.mutedForeground} />
            {totalBorrowedMinutes > 0 && (
              <RingStat label="Borrowed" value={`+${totalBorrowedMinutes}m`} color={colors.orange} />
            )}
          </View>
        </View>

        {/* Tomorrow alert */}
        {totalTomorrowDeduction > 0 && (
          <View style={[styles.tomorrowCard, { backgroundColor: colors.destructive + "12", borderColor: colors.destructive + "30" }]}>
            <Feather name="alert-circle" size={18} color={colors.destructive} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.tomorrowTitle, { color: colors.destructive }]}>
                Tomorrow's cut: -{totalTomorrowDeduction} min
              </Text>
              <Text style={[styles.tomorrowDesc, { color: colors.mutedForeground }]}>
                Borrowed today will be deducted from tomorrow's limit
              </Text>
            </View>
          </View>
        )}

        {/* Platform quick stats */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Platforms</Text>
        {enabledPlatforms.map((p) => {
          const rec = getTodayUsage(p.id);
          const isActive = activeSession?.platformId === p.id;
          const used = (rec?.minutesUsed ?? 0) + (isActive ? Math.floor(elapsedSeconds / 60) : 0);
          const borrowed = rec?.minutesBorrowed ?? 0;
          const remaining = getRemainingMinutes(p.id) - (isActive ? Math.floor(elapsedSeconds / 60) : 0);
          const pct = Math.min(used / (p.dailyLimitMinutes + borrowed), 1);

          return (
            <TouchableOpacity
              key={p.id}
              style={[styles.quickCard, { backgroundColor: isDark ? colors.card : colors.surface, borderColor: isActive ? p.color : colors.border }]}
              onPress={() => setBorrowTarget(p)}
              activeOpacity={0.8}
            >
              <View style={[styles.quickIcon, { backgroundColor: p.color + "22" }]}>
                <Feather name={p.icon as any} size={18} color={p.color} />
              </View>
              <View style={{ flex: 1 }}>
                <View style={styles.quickTopRow}>
                  <Text style={[styles.quickName, { color: colors.foreground }]}>{p.name}</Text>
                  <Text style={[styles.quickRemaining, { color: remaining <= 0 ? colors.destructive : colors.foreground }]}>
                    {remaining > 0 ? `${remaining}m left` : "Exhausted"}
                  </Text>
                </View>
                <View style={[styles.progressTrack, { backgroundColor: colors.muted }]}>
                  <View style={[styles.progressFill, { width: `${pct * 100}%` as any, backgroundColor: remaining <= 0 ? colors.destructive : p.color }]} />
                </View>
              </View>
            </TouchableOpacity>
          );
        })}

        {/* Today's borrows */}
        {todayBorrows.length > 0 && (
          <>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Today's Borrows</Text>
            {todayBorrows.map((b) => {
              const plat = platforms.find((p) => p.id === b.platformId);
              return (
                <View key={b.id} style={[styles.borrowItem, { backgroundColor: isDark ? colors.card : colors.surface, borderColor: colors.border }]}>
                  <View style={[styles.quickIcon, { backgroundColor: (plat?.color ?? colors.primary) + "22" }]}>
                    <Feather name={(plat?.icon as any) ?? "clock"} size={16} color={plat?.color ?? colors.primary} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.borrowName, { color: colors.foreground }]}>{plat?.name}</Text>
                    <Text style={[styles.borrowMeta, { color: colors.mutedForeground }]}>
                      Repaid from tomorrow · -{b.minutesBorrowed}m
                    </Text>
                  </View>
                  <View style={[styles.borrowBadge, { backgroundColor: colors.orange + "22" }]}>
                    <Text style={[styles.borrowBadgeText, { color: colors.orange }]}>+{b.minutesBorrowed}m</Text>
                  </View>
                </View>
              );
            })}
          </>
        )}
      </ScrollView>

      <BorrowModal platform={borrowTarget} onClose={() => setBorrowTarget(null)} />
    </View>
  );
}

function RingStat({ label, value, color }: { label: string; value: string; color: string }) {
  const colors = useColors();
  return (
    <View style={{ alignItems: "center" }}>
      <Text style={{ fontFamily: "Inter_700Bold", fontSize: 18, color }}>{value}</Text>
      <Text style={{ fontFamily: "Inter_400Regular", fontSize: 11, color: colors.mutedForeground }}>{label}</Text>
    </View>
  );
}

function formatSeconds(s: number) {
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 18) return "Good afternoon";
  return "Good evening";
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 14 },
  heroRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
    marginBottom: 4,
  },
  greeting: { fontFamily: "Inter_400Regular", fontSize: 13 },
  heroTitle: { fontFamily: "Inter_700Bold", fontSize: 28 },
  dateChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
  },
  dateText: { fontFamily: "Inter_600SemiBold", fontSize: 13 },
  activeBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 12,
    borderRadius: 14,
    borderWidth: 1,
  },
  activeDot: { width: 8, height: 8, borderRadius: 4 },
  activeName: { fontFamily: "Inter_600SemiBold", fontSize: 14, flex: 1 },
  activeTime: { fontFamily: "Inter_700Bold", fontSize: 16 },
  ringCard: {
    borderRadius: 22,
    borderWidth: 1,
    padding: 24,
    alignItems: "center",
    gap: 20,
  },
  ringStats: {
    flexDirection: "row",
    gap: 28,
  },
  tomorrowCard: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
  },
  tomorrowTitle: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  tomorrowDesc: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 2 },
  sectionTitle: { fontFamily: "Inter_700Bold", fontSize: 17, marginTop: 4 },
  quickCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
  },
  quickIcon: {
    width: 38,
    height: 38,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  quickTopRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 6,
  },
  quickName: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  quickRemaining: { fontFamily: "Inter_500Medium", fontSize: 12 },
  progressTrack: {
    height: 4,
    borderRadius: 2,
    overflow: "hidden",
  },
  progressFill: {
    height: "100%",
    borderRadius: 2,
  },
  borrowItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
  },
  borrowName: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  borrowMeta: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 2 },
  borrowBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  borrowBadgeText: { fontFamily: "Inter_700Bold", fontSize: 13 },
});
