import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useApp, Platform as AIPlatform } from "@/context/AppContext";
import { PlatformCard } from "@/components/PlatformCard";
import { BorrowModal } from "@/components/BorrowModal";

export default function PlatformsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { platforms } = useApp();
  const [borrowTarget, setBorrowTarget] = useState<AIPlatform | null>(null);

  const enabled = platforms.filter((p) => p.enabled);
  const disabled = platforms.filter((p) => !p.enabled);

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: Platform.OS === "web" ? 67 + 16 : insets.top + 16,
            paddingBottom: Platform.OS === "web" ? 34 + 84 : insets.bottom + 84,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Text style={[styles.pageTitle, { color: colors.foreground }]}>AI Platforms</Text>
        <Text style={[styles.pageSubtitle, { color: colors.mutedForeground }]}>
          Track and manage your time on each platform
        </Text>

        {enabled.map((p) => (
          <PlatformCard key={p.id} platform={p} onBorrow={setBorrowTarget} />
        ))}

        {disabled.length > 0 && (
          <>
            <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>
              Disabled Platforms
            </Text>
            {disabled.map((p) => (
              <View key={p.id} style={[styles.disabledCard, { backgroundColor: colors.muted, borderColor: colors.border }]}>
                <View style={[styles.disabledIcon, { backgroundColor: colors.border }]}>
                  <Text style={{ color: colors.mutedForeground, fontSize: 16 }}>—</Text>
                </View>
                <Text style={[styles.disabledName, { color: colors.mutedForeground }]}>{p.name}</Text>
                <Text style={[styles.disabledHint, { color: colors.mutedForeground }]}>Enable in Settings</Text>
              </View>
            ))}
          </>
        )}
      </ScrollView>

      <BorrowModal platform={borrowTarget} onClose={() => setBorrowTarget(null)} />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 4 },
  pageTitle: { fontFamily: "Inter_700Bold", fontSize: 28, marginBottom: 4 },
  pageSubtitle: { fontFamily: "Inter_400Regular", fontSize: 14, marginBottom: 12 },
  sectionLabel: {
    fontFamily: "Inter_500Medium",
    fontSize: 13,
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginTop: 8,
    marginBottom: 8,
  },
  disabledCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    marginBottom: 8,
  },
  disabledIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  disabledName: { fontFamily: "Inter_600SemiBold", fontSize: 14, flex: 1 },
  disabledHint: { fontFamily: "Inter_400Regular", fontSize: 12 },
});
