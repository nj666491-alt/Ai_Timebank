import React, { useMemo } from "react";
import {
  View,
  Text,
  StyleSheet,
  SectionList,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { useApp, UsageRecord, BorrowRecord } from "@/context/AppContext";

type HistoryEntry =
  | { type: "usage"; record: UsageRecord }
  | { type: "borrow"; record: BorrowRecord };

interface Section {
  title: string;
  data: HistoryEntry[];
}

export default function HistoryScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { usageRecords, borrowRecords, platforms } = useApp();

  const sections = useMemo<Section[]>(() => {
    const dateMap = new Map<string, HistoryEntry[]>();

    for (const rec of usageRecords) {
      if (rec.minutesUsed === 0) continue;
      const entries = dateMap.get(rec.date) ?? [];
      entries.push({ type: "usage", record: rec });
      dateMap.set(rec.date, entries);
    }

    for (const rec of borrowRecords) {
      const entries = dateMap.get(rec.borrowDate) ?? [];
      entries.push({ type: "borrow", record: rec });
      dateMap.set(rec.borrowDate, entries);
    }

    return Array.from(dateMap.entries())
      .sort(([a], [b]) => b.localeCompare(a))
      .map(([date, data]) => ({
        title: formatDate(date),
        data,
      }));
  }, [usageRecords, borrowRecords]);

  if (sections.length === 0) {
    return (
      <View style={[styles.root, styles.empty, { backgroundColor: colors.background }]}>
        <Feather name="clock" size={44} color={colors.mutedForeground} />
        <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No history yet</Text>
        <Text style={[styles.emptyDesc, { color: colors.mutedForeground }]}>
          Start a timer on a platform to see your usage history
        </Text>
      </View>
    );
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <SectionList
        sections={sections}
        keyExtractor={(item, i) =>
          item.type === "usage" ? item.record.id : item.record.id + i
        }
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingTop: Platform.OS === "web" ? 67 + 16 : insets.top + 16,
          paddingBottom: Platform.OS === "web" ? 34 + 84 : insets.bottom + 84,
          gap: 4,
        }}
        ListHeaderComponent={
          <View style={{ marginBottom: 12 }}>
            <Text style={[styles.pageTitle, { color: colors.foreground }]}>History</Text>
            <Text style={[styles.pageSubtitle, { color: colors.mutedForeground }]}>
              Your AI usage log
            </Text>
          </View>
        }
        renderSectionHeader={({ section }) => (
          <View style={[styles.sectionHeader, { backgroundColor: colors.background }]}>
            <Text style={[styles.sectionDate, { color: colors.mutedForeground }]}>
              {section.title}
            </Text>
          </View>
        )}
        renderItem={({ item }) => {
          const plat = platforms.find(
            (p) => p.id === (item.type === "usage" ? item.record.platformId : item.record.platformId)
          );
          if (item.type === "usage") {
            return (
              <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <View style={[styles.icon, { backgroundColor: (plat?.color ?? colors.primary) + "22" }]}>
                  <Feather name={(plat?.icon as any) ?? "activity"} size={16} color={plat?.color ?? colors.primary} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.cardName, { color: colors.foreground }]}>{plat?.name ?? item.record.platformId}</Text>
                  <Text style={[styles.cardMeta, { color: colors.mutedForeground }]}>Usage session</Text>
                </View>
                <View style={{ alignItems: "flex-end" }}>
                  <Text style={[styles.cardValue, { color: colors.primary }]}>
                    {item.record.minutesUsed}m
                  </Text>
                  {item.record.minutesBorrowed > 0 && (
                    <Text style={[styles.cardSub, { color: colors.orange }]}>
                      +{item.record.minutesBorrowed}m borrowed
                    </Text>
                  )}
                </View>
              </View>
            );
          }
          return (
            <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.orange + "44" }]}>
              <View style={[styles.icon, { backgroundColor: colors.orange + "22" }]}>
                <Feather name="clock" size={16} color={colors.orange} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.cardName, { color: colors.foreground }]}>{plat?.name ?? item.record.platformId}</Text>
                <Text style={[styles.cardMeta, { color: colors.mutedForeground }]}>
                  Borrowed · repaid {formatDate(item.record.repayDate)}
                </Text>
              </View>
              <View style={{ alignItems: "flex-end" }}>
                <Text style={[styles.cardValue, { color: colors.orange }]}>
                  +{item.record.minutesBorrowed}m
                </Text>
                <Text style={[styles.cardSub, { color: colors.destructive }]}>
                  -{item.record.minutesBorrowed}m tmrw
                </Text>
              </View>
            </View>
          );
        }}
        stickySectionHeadersEnabled
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

function formatDate(dateStr: string) {
  const today = new Date().toISOString().split("T")[0];
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split("T")[0];
  if (dateStr === today) return "Today";
  if (dateStr === tomorrow) return "Tomorrow";
  return new Date(dateStr).toLocaleDateString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
  });
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  empty: { alignItems: "center", justifyContent: "center", gap: 12, padding: 40 },
  emptyTitle: { fontFamily: "Inter_700Bold", fontSize: 20 },
  emptyDesc: { fontFamily: "Inter_400Regular", fontSize: 14, textAlign: "center", lineHeight: 22 },
  pageTitle: { fontFamily: "Inter_700Bold", fontSize: 28 },
  pageSubtitle: { fontFamily: "Inter_400Regular", fontSize: 14, marginTop: 4 },
  sectionHeader: { paddingVertical: 8 },
  sectionDate: {
    fontFamily: "Inter_500Medium",
    fontSize: 13,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  card: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    marginBottom: 8,
  },
  icon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  cardName: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  cardMeta: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 2 },
  cardValue: { fontFamily: "Inter_700Bold", fontSize: 16 },
  cardSub: { fontFamily: "Inter_400Regular", fontSize: 11, marginTop: 2 },
});
