import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Switch,
  TouchableOpacity,
  Alert,
  Platform,
  TextInput,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import { useApp, Platform as AIPlatform } from "@/context/AppContext";

export default function SettingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { platforms, updatePlatform, clearAllData } = useApp();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editLimit, setEditLimit] = useState("");

  const handleToggle = (platform: AIPlatform) => {
    Haptics.selectionAsync();
    updatePlatform({ ...platform, enabled: !platform.enabled });
  };

  const handleEditLimit = (platform: AIPlatform) => {
    setEditingId(platform.id);
    setEditLimit(String(platform.dailyLimitMinutes));
  };

  const handleSaveLimit = (platform: AIPlatform) => {
    const val = parseInt(editLimit);
    if (!isNaN(val) && val > 0 && val <= 480) {
      updatePlatform({ ...platform, dailyLimitMinutes: val });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    setEditingId(null);
  };

  const handleClearData = () => {
    Alert.alert(
      "Clear All Data",
      "This will erase all usage history and borrow records. This cannot be undone.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Clear",
          style: "destructive",
          onPress: async () => {
            await clearAllData();
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
          },
        },
      ]
    );
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: Platform.OS === "web" ? 67 + 16 : insets.top + 16,
            paddingBottom: Platform.OS === "web" ? 34 + 84 : insets.bottom + 84,
          },
        ]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <Text style={[styles.pageTitle, { color: colors.foreground }]}>Settings</Text>

        {/* Platform limits */}
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>Platform Limits</Text>
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {platforms.map((platform, idx) => (
            <View key={platform.id}>
              <View style={styles.platformRow}>
                <View style={[styles.icon, { backgroundColor: platform.color + "22" }]}>
                  <Feather name={platform.icon as any} size={18} color={platform.color} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.platName, { color: colors.foreground }]}>{platform.name}</Text>
                  {editingId === platform.id ? (
                    <View style={styles.editRow}>
                      <TextInput
                        style={[styles.limitInput, { color: colors.foreground, borderColor: platform.color, backgroundColor: colors.muted }]}
                        value={editLimit}
                        onChangeText={setEditLimit}
                        keyboardType="numeric"
                        maxLength={3}
                        autoFocus
                      />
                      <Text style={[styles.minLabel, { color: colors.mutedForeground }]}>min</Text>
                      <TouchableOpacity
                        onPress={() => handleSaveLimit(platform)}
                        style={[styles.saveBtn, { backgroundColor: platform.color }]}
                      >
                        <Feather name="check" size={14} color="#fff" />
                      </TouchableOpacity>
                    </View>
                  ) : (
                    <TouchableOpacity onPress={() => handleEditLimit(platform)}>
                      <Text style={[styles.limitText, { color: colors.mutedForeground }]}>
                        {platform.dailyLimitMinutes} min/day · tap to edit
                      </Text>
                    </TouchableOpacity>
                  )}
                </View>
                <Switch
                  value={platform.enabled}
                  onValueChange={() => handleToggle(platform)}
                  trackColor={{ false: colors.muted, true: platform.color + "88" }}
                  thumbColor={platform.enabled ? platform.color : colors.mutedForeground}
                />
              </View>
              {idx < platforms.length - 1 && (
                <View style={[styles.divider, { backgroundColor: colors.border }]} />
              )}
            </View>
          ))}
        </View>

        {/* About */}
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>About</Text>
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <InfoRow label="Version" value="1.0.0" colors={colors} />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <InfoRow label="How borrowing works" value="" colors={colors} />
          <Text style={[styles.infoText, { color: colors.mutedForeground }]}>
            Borrowing time lets you use extra minutes today by deducting from tomorrow's allowance. 
            You can borrow up to 50% of any platform's daily limit. This helps you stay productive 
            without breaking the free tier rules.
          </Text>
        </View>

        {/* Danger zone */}
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>Data</Text>
        <TouchableOpacity
          style={[styles.dangerBtn, { backgroundColor: colors.destructive + "12", borderColor: colors.destructive + "30" }]}
          onPress={handleClearData}
          activeOpacity={0.8}
        >
          <Feather name="trash-2" size={18} color={colors.destructive} />
          <Text style={[styles.dangerText, { color: colors.destructive }]}>Clear All Usage Data</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

function InfoRow({ label, value, colors }: { label: string; value: string; colors: any }) {
  return (
    <View style={styles.infoRow}>
      <Text style={[styles.infoLabel, { color: colors.foreground }]}>{label}</Text>
      {value ? <Text style={[styles.infoValue, { color: colors.mutedForeground }]}>{value}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 12 },
  pageTitle: { fontFamily: "Inter_700Bold", fontSize: 28, marginBottom: 4 },
  sectionLabel: {
    fontFamily: "Inter_500Medium",
    fontSize: 12,
    textTransform: "uppercase",
    letterSpacing: 0.8,
    marginTop: 8,
  },
  section: {
    borderRadius: 18,
    borderWidth: 1,
    overflow: "hidden",
  },
  platformRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 16,
  },
  icon: {
    width: 38,
    height: 38,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  platName: { fontFamily: "Inter_600SemiBold", fontSize: 15 },
  limitText: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 2 },
  editRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginTop: 4,
  },
  limitInput: {
    width: 56,
    borderWidth: 1,
    borderRadius: 8,
    padding: 4,
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
    textAlign: "center",
  },
  minLabel: { fontFamily: "Inter_400Regular", fontSize: 13 },
  saveBtn: {
    width: 28,
    height: 28,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  divider: { height: 1, marginLeft: 66 },
  infoRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 16,
  },
  infoLabel: { fontFamily: "Inter_500Medium", fontSize: 15 },
  infoValue: { fontFamily: "Inter_400Regular", fontSize: 14 },
  infoText: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    lineHeight: 20,
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  dangerBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
  },
  dangerText: { fontFamily: "Inter_600SemiBold", fontSize: 15 },
});
