import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Platform,
  Alert,
  KeyboardAvoidingView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import { useFeedback, FeedbackEntry, FEEDBACK_CATEGORIES, FeedbackCategory } from "@/context/FeedbackContext";

const CATEGORY_ICONS: Record<FeedbackCategory, string> = {
  suggestion: "lightbulb",
  bug: "alert-circle",
  review: "star",
  ui: "layout",
  other: "message-circle",
};

const CATEGORY_LABELS: Record<FeedbackCategory, string> = {
  suggestion: "Suggestion",
  bug: "Bug Report",
  review: "Review",
  ui: "UI Improvement",
  other: "Other",
};

const CATEGORY_COLORS: Record<FeedbackCategory, string> = {
  suggestion: "#6366f1",
  bug: "#ef4444",
  review: "#f59e0b",
  ui: "#10b981",
  other: "#8b5cf6",
};

export default function FeedbackScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { feedbackList, addFeedback, deleteFeedback } = useFeedback();

  const [rating, setRating] = useState(0);
  const [hoveredStar, setHoveredStar] = useState(0);
  const [category, setCategory] = useState<FeedbackCategory>("suggestion");
  const [message, setMessage] = useState("");
  const [name, setName] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [showForm, setShowForm] = useState(true);

  const handleSubmit = async () => {
    if (rating === 0) {
      Alert.alert("Rating required", "Please give a star rating before submitting.");
      return;
    }
    if (message.trim().length < 10) {
      Alert.alert("Too short", "Please write at least 10 characters in your feedback.");
      return;
    }
    setSubmitting(true);
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await addFeedback({ rating, category, message: message.trim(), name: name.trim() });
    setRating(0);
    setCategory("suggestion");
    setMessage("");
    setName("");
    setSubmitting(false);
    setShowForm(false);
    setTimeout(() => setShowForm(true), 100);
    Alert.alert("Thank you!", "Your feedback has been saved. We'll use it to improve the app.");
  };

  const handleDelete = (id: string) => {
    Alert.alert("Delete feedback", "Remove this feedback entry?", [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: () => deleteFeedback(id) },
    ]);
  };

  const displayStars = hoveredStar || rating;

  return (
    <KeyboardAvoidingView
      style={[styles.root, { backgroundColor: colors.background }]}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: Platform.OS === "web" ? 67 + 16 : insets.top + 16,
            paddingBottom: Platform.OS === "web" ? 34 + 100 : insets.bottom + 100,
          },
        ]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Header */}
        <View style={styles.headerRow}>
          <View>
            <Text style={[styles.pageTitle, { color: colors.foreground }]}>Feedback</Text>
            <Text style={[styles.pageSubtitle, { color: colors.mutedForeground }]}>
              Help us improve AI Time Bank
            </Text>
          </View>
          <View style={[styles.countBadge, { backgroundColor: colors.secondary }]}>
            <Text style={[styles.countText, { color: colors.primary }]}>
              {feedbackList.length} submitted
            </Text>
          </View>
        </View>

        {/* Form card */}
        {showForm && (
          <View style={[styles.formCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.formTitle, { color: colors.foreground }]}>Leave a Review</Text>

            {/* Stars */}
            <View style={styles.starsRow}>
              {[1, 2, 3, 4, 5].map((star) => (
                <TouchableOpacity
                  key={star}
                  onPress={() => {
                    setRating(star);
                    Haptics.selectionAsync();
                  }}
                  onPressIn={() => setHoveredStar(star)}
                  onPressOut={() => setHoveredStar(0)}
                  hitSlop={{ top: 8, bottom: 8, left: 4, right: 4 }}
                >
                  <Feather
                    name={displayStars >= star ? "star" : "star"}
                    size={36}
                    color={displayStars >= star ? "#f59e0b" : colors.border}
                    style={{ opacity: displayStars >= star ? 1 : 0.4 }}
                  />
                </TouchableOpacity>
              ))}
            </View>
            {rating > 0 && (
              <Text style={[styles.ratingLabel, { color: colors.orange }]}>
                {["", "Poor", "Fair", "Good", "Great", "Excellent!"][rating]}
              </Text>
            )}

            {/* Category */}
            <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>Category</Text>
            <View style={styles.categoryGrid}>
              {(Object.keys(CATEGORY_LABELS) as FeedbackCategory[]).map((cat) => (
                <TouchableOpacity
                  key={cat}
                  style={[
                    styles.catBtn,
                    {
                      backgroundColor:
                        category === cat
                          ? CATEGORY_COLORS[cat] + "22"
                          : colors.muted,
                      borderColor:
                        category === cat ? CATEGORY_COLORS[cat] : colors.border,
                    },
                  ]}
                  onPress={() => {
                    setCategory(cat);
                    Haptics.selectionAsync();
                  }}
                >
                  <Feather
                    name={CATEGORY_ICONS[cat] as any}
                    size={14}
                    color={category === cat ? CATEGORY_COLORS[cat] : colors.mutedForeground}
                  />
                  <Text
                    style={[
                      styles.catText,
                      {
                        color:
                          category === cat
                            ? CATEGORY_COLORS[cat]
                            : colors.mutedForeground,
                      },
                    ]}
                  >
                    {CATEGORY_LABELS[cat]}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Name (optional) */}
            <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>
              Your name (optional)
            </Text>
            <TextInput
              style={[
                styles.input,
                {
                  color: colors.foreground,
                  backgroundColor: colors.muted,
                  borderColor: name ? colors.primary : colors.border,
                },
              ]}
              placeholder="Anonymous"
              placeholderTextColor={colors.mutedForeground}
              value={name}
              onChangeText={setName}
              maxLength={40}
              returnKeyType="next"
            />

            {/* Message */}
            <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>
              Your feedback *
            </Text>
            <TextInput
              style={[
                styles.textarea,
                {
                  color: colors.foreground,
                  backgroundColor: colors.muted,
                  borderColor: message.length >= 10 ? colors.primary : colors.border,
                },
              ]}
              placeholder="Share your thoughts, ideas, or issues..."
              placeholderTextColor={colors.mutedForeground}
              value={message}
              onChangeText={setMessage}
              multiline
              numberOfLines={5}
              maxLength={500}
              textAlignVertical="top"
            />
            <Text style={[styles.charCount, { color: colors.mutedForeground }]}>
              {message.length}/500
            </Text>

            {/* Submit */}
            <TouchableOpacity
              style={[
                styles.submitBtn,
                {
                  backgroundColor:
                    rating > 0 && message.length >= 10
                      ? CATEGORY_COLORS[category]
                      : colors.muted,
                  opacity: submitting ? 0.7 : 1,
                },
              ]}
              onPress={handleSubmit}
              disabled={submitting}
              activeOpacity={0.8}
            >
              <Feather
                name="send"
                size={16}
                color={rating > 0 && message.length >= 10 ? "#fff" : colors.mutedForeground}
              />
              <Text
                style={[
                  styles.submitText,
                  {
                    color:
                      rating > 0 && message.length >= 10
                        ? "#fff"
                        : colors.mutedForeground,
                  },
                ]}
              >
                {submitting ? "Submitting..." : "Submit Feedback"}
              </Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Past feedback */}
        {feedbackList.length > 0 && (
          <>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              Submitted Feedback
            </Text>
            {feedbackList
              .slice()
              .reverse()
              .map((item) => (
                <FeedbackCard
                  key={item.id}
                  item={item}
                  onDelete={() => handleDelete(item.id)}
                  colors={colors}
                />
              ))}
          </>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function FeedbackCard({
  item,
  onDelete,
  colors,
}: {
  item: FeedbackEntry;
  onDelete: () => void;
  colors: any;
}) {
  const catColor = CATEGORY_COLORS[item.category];
  return (
    <View
      style={[
        styles.feedCard,
        { backgroundColor: colors.card, borderColor: colors.border },
      ]}
    >
      <View style={styles.feedHeader}>
        <View style={[styles.catPill, { backgroundColor: catColor + "20" }]}>
          <Feather name={CATEGORY_ICONS[item.category] as any} size={12} color={catColor} />
          <Text style={[styles.catPillText, { color: catColor }]}>
            {CATEGORY_LABELS[item.category]}
          </Text>
        </View>
        <View style={styles.feedHeaderRight}>
          {/* Stars */}
          <View style={styles.miniStars}>
            {[1, 2, 3, 4, 5].map((s) => (
              <Feather
                key={s}
                name="star"
                size={11}
                color={item.rating >= s ? "#f59e0b" : colors.border}
                style={{ opacity: item.rating >= s ? 1 : 0.3 }}
              />
            ))}
          </View>
          <TouchableOpacity onPress={onDelete} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <Feather name="trash-2" size={14} color={colors.mutedForeground} />
          </TouchableOpacity>
        </View>
      </View>

      {item.name ? (
        <Text style={[styles.feedName, { color: colors.primary }]}>{item.name}</Text>
      ) : null}
      <Text style={[styles.feedMessage, { color: colors.foreground }]}>{item.message}</Text>
      <Text style={[styles.feedDate, { color: colors.mutedForeground }]}>
        {new Date(item.createdAt).toLocaleDateString("en-US", {
          month: "short",
          day: "numeric",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
        })}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 14 },
  headerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
    marginBottom: 4,
  },
  pageTitle: { fontFamily: "Inter_700Bold", fontSize: 28 },
  pageSubtitle: { fontFamily: "Inter_400Regular", fontSize: 14, marginTop: 2 },
  countBadge: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 10 },
  countText: { fontFamily: "Inter_600SemiBold", fontSize: 13 },

  formCard: {
    borderRadius: 22,
    borderWidth: 1,
    padding: 20,
    gap: 12,
  },
  formTitle: { fontFamily: "Inter_700Bold", fontSize: 18 },

  starsRow: {
    flexDirection: "row",
    gap: 8,
    justifyContent: "center",
    paddingVertical: 8,
  },
  ratingLabel: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
    textAlign: "center",
    marginTop: -4,
  },

  fieldLabel: {
    fontFamily: "Inter_500Medium",
    fontSize: 12,
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginTop: 4,
  },
  categoryGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  catBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
    borderWidth: 1,
  },
  catText: { fontFamily: "Inter_500Medium", fontSize: 12 },

  input: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    fontFamily: "Inter_400Regular",
    fontSize: 14,
  },
  textarea: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    fontFamily: "Inter_400Regular",
    fontSize: 14,
    minHeight: 110,
  },
  charCount: {
    fontFamily: "Inter_400Regular",
    fontSize: 11,
    textAlign: "right",
    marginTop: -6,
  },

  submitBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 14,
    borderRadius: 14,
    marginTop: 4,
  },
  submitText: { fontFamily: "Inter_700Bold", fontSize: 15 },

  sectionTitle: { fontFamily: "Inter_700Bold", fontSize: 17, marginTop: 6 },

  feedCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    gap: 8,
  },
  feedHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  catPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  catPillText: { fontFamily: "Inter_600SemiBold", fontSize: 11 },
  feedHeaderRight: { flexDirection: "row", alignItems: "center", gap: 10 },
  miniStars: { flexDirection: "row", gap: 2 },
  feedName: { fontFamily: "Inter_600SemiBold", fontSize: 13 },
  feedMessage: {
    fontFamily: "Inter_400Regular",
    fontSize: 14,
    lineHeight: 20,
  },
  feedDate: { fontFamily: "Inter_400Regular", fontSize: 11 },
});
