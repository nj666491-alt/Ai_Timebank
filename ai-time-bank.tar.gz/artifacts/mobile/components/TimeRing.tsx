import React from "react";
import { View, Text, StyleSheet, ViewStyle } from "react-native";
import Svg, { Circle } from "react-native-svg";
import { useColors } from "@/hooks/useColors";

interface TimeRingProps {
  used: number;
  total: number;
  borrowed: number;
  size?: number;
  color?: string;
  style?: ViewStyle;
  label?: string;
  sublabel?: string;
}

export function TimeRing({
  used,
  total,
  borrowed,
  size = 120,
  color,
  style,
  label,
  sublabel,
}: TimeRingProps) {
  const colors = useColors();
  const stroke = color ?? colors.primary;
  const strokeWidth = size * 0.08;
  const radius = (size - strokeWidth * 2) / 2;
  const circumference = 2 * Math.PI * radius;

  const usedPct = Math.min(used / Math.max(total, 1), 1);
  const borrowedPct = Math.min(borrowed / Math.max(total, 1), 1 - usedPct);

  const usedOffset = circumference * (1 - usedPct);
  const borrowedOffset = circumference * (1 - usedPct - borrowedPct);

  const remainingMinutes = Math.max(total - used, 0);
  const hours = Math.floor(remainingMinutes / 60);
  const mins = remainingMinutes % 60;
  const displayLabel = label ?? (hours > 0 ? `${hours}h ${mins}m` : `${mins}m`);

  return (
    <View style={[{ width: size, height: size, alignItems: "center", justifyContent: "center" }, style]}>
      <Svg width={size} height={size} style={StyleSheet.absoluteFill}>
        {/* Background track */}
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={colors.muted}
          strokeWidth={strokeWidth}
          fill="transparent"
        />
        {/* Used time */}
        {usedPct > 0 && (
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={stroke}
            strokeWidth={strokeWidth}
            fill="transparent"
            strokeDasharray={`${circumference}`}
            strokeDashoffset={usedOffset}
            strokeLinecap="round"
            rotation="-90"
            origin={`${size / 2}, ${size / 2}`}
          />
        )}
        {/* Borrowed time (shown as orange/warning band) */}
        {borrowedPct > 0 && (
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={colors.orange}
            strokeWidth={strokeWidth * 0.5}
            fill="transparent"
            strokeDasharray={`${circumference * borrowedPct} ${circumference * (1 - borrowedPct)}`}
            strokeDashoffset={borrowedOffset - circumference * (1 - usedPct - borrowedPct)}
            strokeLinecap="round"
            rotation="-90"
            origin={`${size / 2}, ${size / 2}`}
          />
        )}
      </Svg>
      <View style={{ alignItems: "center" }}>
        <Text style={[styles.label, { color: colors.foreground, fontSize: size * 0.17 }]}>
          {displayLabel}
        </Text>
        {sublabel && (
          <Text style={[styles.sublabel, { color: colors.mutedForeground, fontSize: size * 0.1 }]}>
            {sublabel}
          </Text>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  label: {
    fontFamily: "Inter_700Bold",
    textAlign: "center",
  },
  sublabel: {
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    marginTop: 2,
  },
});
