import React, { useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  useColorScheme,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import { useApp, Platform } from "@/context/AppContext";
import { TimeRing } from "@/components/TimeRing";

interface PlatformCardProps {
  platform: Platform;
  onBorrow: (platform: Platform) => void;
}

export function PlatformCard({ platform, onBorrow }: PlatformCardProps) {
  const colors = useColors();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";
  const { activeSession, elapsedSeconds, startSession, stopSession, getTodayUsage, getTomorrowDeduction, getRemainingMinutes } = useApp();

  const isActive = activeSession?.platformId === platform.id;
  const todayUsage = getTodayUsage(platform.id);
  const minutesUsed = todayUsage?.minutesUsed ?? 0;
  const minutesBorrowed = todayUsage?.minutesBorrowed ?? 0;
  const remainingMinutes = getRemainingMinutes(platform.id);
  const tomorrowDeduction = getTomorrowDeduction(platform.id);
  const totalWithBorrowed = platform.dailyLimitMinutes + minutesBorrowed;

  const currentElapsed = isActive ? Math.floor(elapsedSeconds / 60) : 0;
  const displayUsed = minutesUsed + currentElapsed;
  const isExhausted = remainingMinutes <= 0;

  const handlePress = useCallback(async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (isActive) {
      stopSession();
    } else if (!isExhausted) {
      startSession(platform.id);
    }
  }, [isActive, isExhausted, platform.id, startSession, stopSession]);

  const handleBorrow = useCallback(async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    onBorrow(platform);
  }, [platform, onBorrow]);

  const cardBg = isDark ? colors.card : colors.surface;
  const maxBorrow = Math.floor(platform.dailyLimitMinutes * 0.5);
  const canBorrow = minutesBorrowed < maxBorrow;

  return (
    <View style={[styles.card, { backgroundColor: cardBg, borderColor: isActive ? platform.color : colors.border }]}>
      <View style={styles.header}>
        <View style={[styles.iconBadge, { backgroundColor: platform.color + "22" }]}>
          <Feather name={platform.icon as any} size={20} color={platform.color} />
        </View>
        <View style={styles.titleBlock}>
          <Text style={[styles.name, { color: colors.foreground }]}>{platform.name}</Text>
          <Text style={[styles.limit, { color: colors.mutedForeground }]}>
            {platform.dailyLimitMinutes}min/day free
          </Text>
        </View>
        {isActive && (
          <View style={[styles.liveBadge, { backgroundColor: platform.color + "22" }]}>
            <View style={[styles.liveDot, { backgroundColor: platform.color }]} />
            <Text style={[styles.liveText, { color: platform.color }]}>LIVE</Text>
          </View>
        )}
      </View>

      <View style={styles.ringRow}>
        <TimeRing
          used={displayUsed}
          total={totalWithBorrowed}
          borrowed={minutesBorrowed}
          size={100}
          color={isExhausted ? colors.destructive : platform.color}
          sublabel="left"
        />
        <View style={styles.statsCol}>
          <StatRow label="Used today" value={`${displayUsed}m`} color={colors.foreground} />
          <StatRow label="Daily limit" value={`${platform.dailyLimitMinutes}m`} color={colors.mutedForeground} />
          {minutesBorrowed > 0 && (
            <StatRow label="Borrowed" value={`+${minutesBorrowed}m`} color={colors.orange} />
          )}
          {tomorrowDeduction > 0 && (
            <StatRow label="Cut tomorrow" value={`-${tomorrowDeduction}m`} color={colors.destructive} />
          )}
          {isActive && (
            <StatRow label="Session" value={formatSeconds(elapsedSeconds)} color={platform.color} />
          )}
        </View>
      </View>

      <View style={styles.actions}>
        <TouchableOpacity
          style={[
            styles.actionBtn,
            {
              backgroundColor: isActive
                ? colors.destructive + "22"
                : isExhausted
                ? colors.muted
                : platform.color + "22",
              borderColor: isActive ? colors.destructive : isExhausted ? colors.border : platform.color,
            },
          ]}
          onPress={handlePress}
          activeOpacity={0.7}
        >
          <Feather
            name={isActive ? "square" : "play"}
            size={16}
            color={isActive ? colors.destructive : isExhausted ? colors.mutedForeground : platform.color}
          />
          <Text
            style={[
              styles.actionText,
              { color: isActive ? colors.destructive : isExhausted ? colors.mutedForeground : platform.color },
            ]}
          >
            {isActive ? "Stop" : isExhausted ? "Exhausted" : "Start"}
          </Text>
        </TouchableOpacity>

        {!isExhausted && canBorrow && (
          <TouchableOpacity
            style={[styles.borrowBtn, { backgroundColor: colors.orange + "22", borderColor: colors.orange }]}
            onPress={handleBorrow}
            activeOpacity={0.7}
          >
            <Feather name="clock" size={14} color={colors.orange} />
            <Text style={[styles.actionText, { color: colors.orange }]}>Borrow</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

function StatRow({ label, value, color }: { label: string; value: string; color: string }) {
  const colors = useColors();
  return (
    <View style={styles.statRow}>
      <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.statValue, { color }]}>{value}</Text>
    </View>
  );
}

function formatSeconds(s: number) {
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 20,
    borderWidth: 1,
    padding: 18,
    marginBottom: 14,
    gap: 14,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  iconBadge: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  titleBlock: { flex: 1 },
  name: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 16,
  },
  limit: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    marginTop: 2,
  },
  liveBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  liveText: {
    fontFamily: "Inter_700Bold",
    fontSize: 10,
    letterSpacing: 1,
  },
  ringRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 16,
  },
  statsCol: { flex: 1, gap: 4 },
  statRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  statLabel: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
  },
  statValue: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
  },
  actions: {
    flexDirection: "row",
    gap: 10,
  },
  actionBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
  },
  borrowBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 12,
    borderWidth: 1,
  },
  actionText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
  },
});
