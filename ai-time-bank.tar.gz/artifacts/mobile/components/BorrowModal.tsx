import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Alert,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import { useApp, Platform } from "@/context/AppContext";

interface BorrowModalProps {
  platform: Platform | null;
  onClose: () => void;
}

const PRESETS = [5, 10, 15, 20, 30];

export function BorrowModal({ platform, onClose }: BorrowModalProps) {
  const colors = useColors();
  const { borrowTime, getTodayUsage } = useApp();
  const [selected, setSelected] = useState(10);
  const [loading, setLoading] = useState(false);

  const todayUsage = platform ? getTodayUsage(platform.id) : null;
  const alreadyBorrowed = todayUsage?.minutesBorrowed ?? 0;
  const maxBorrow = platform ? Math.floor(platform.dailyLimitMinutes * 0.5) : 0;
  const remaining = maxBorrow - alreadyBorrowed;

  const handleBorrow = useCallback(async () => {
    if (!platform) return;
    setLoading(true);
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    const ok = await borrowTime(platform.id, selected);
    setLoading(false);
    if (ok) {
      Alert.alert(
        "Time Borrowed",
        `+${selected} minutes added to today's ${platform.name} limit.\n\n⚠️ ${selected} minutes will be deducted from tomorrow's allowance.`,
        [{ text: "Got it", onPress: onClose }]
      );
    } else {
      Alert.alert("Cannot Borrow", `You can only borrow up to 50% of your daily limit (${maxBorrow} min total).`);
    }
  }, [platform, selected, borrowTime, maxBorrow, onClose]);

  if (!platform) return null;

  return (
    <Modal visible={!!platform} transparent animationType="slide" onRequestClose={onClose}>
      <TouchableWithoutFeedback onPress={onClose}>
        <View style={styles.backdrop} />
      </TouchableWithoutFeedback>
      <View style={[styles.sheet, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {/* Handle */}
        <View style={[styles.handle, { backgroundColor: colors.border }]} />

        {/* Header */}
        <View style={styles.header}>
          <View style={[styles.iconBadge, { backgroundColor: platform.color + "22" }]}>
            <Feather name="clock" size={22} color={platform.color} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.title, { color: colors.foreground }]}>Borrow Time</Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
              {platform.name} · Max {remaining}m available
            </Text>
          </View>
          <TouchableOpacity onPress={onClose} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
            <Feather name="x" size={22} color={colors.mutedForeground} />
          </TouchableOpacity>
        </View>

        {/* Warning box */}
        <View style={[styles.warningBox, { backgroundColor: colors.orange + "18", borderColor: colors.orange + "44" }]}>
          <Feather name="alert-triangle" size={16} color={colors.orange} />
          <Text style={[styles.warningText, { color: colors.orange }]}>
            Borrowed time is cut from tomorrow's allowance. Use wisely.
          </Text>
        </View>

        {/* Presets */}
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>Select amount</Text>
        <View style={styles.presets}>
          {PRESETS.filter((p) => p <= remaining).map((preset) => (
            <TouchableOpacity
              key={preset}
              style={[
                styles.presetBtn,
                {
                  backgroundColor: selected === preset ? platform.color : colors.muted,
                  borderColor: selected === preset ? platform.color : colors.border,
                },
              ]}
              onPress={() => {
                setSelected(preset);
                Haptics.selectionAsync();
              }}
            >
              <Text
                style={[
                  styles.presetText,
                  { color: selected === preset ? "#fff" : colors.foreground },
                ]}
              >
                {preset}m
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Summary */}
        <View style={[styles.summary, { backgroundColor: colors.surfaceAlt, borderColor: colors.border }]}>
          <SummaryRow label="Borrow today" value={`+${selected} min`} color={colors.green} />
          <SummaryRow label="Cut from tomorrow" value={`-${selected} min`} color={colors.destructive} />
          <SummaryRow
            label="Total borrowed today"
            value={`${alreadyBorrowed + selected} / ${maxBorrow} min`}
            color={colors.foreground}
          />
        </View>

        {/* Confirm */}
        <TouchableOpacity
          style={[styles.confirmBtn, { backgroundColor: platform.color, opacity: loading ? 0.7 : 1 }]}
          onPress={handleBorrow}
          disabled={loading || remaining <= 0}
          activeOpacity={0.8}
        >
          <Feather name="check" size={18} color="#fff" />
          <Text style={styles.confirmText}>
            {remaining <= 0 ? "Limit reached" : `Borrow ${selected} minutes`}
          </Text>
        </TouchableOpacity>
      </View>
    </Modal>
  );
}

function SummaryRow({ label, value, color }: { label: string; value: string; color: string }) {
  const colors = useColors();
  return (
    <View style={styles.summaryRow}>
      <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.summaryValue, { color }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
  },
  sheet: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    borderBottomWidth: 0,
    padding: 24,
    paddingBottom: 40,
    gap: 16,
  },
  handle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    alignSelf: "center",
    marginBottom: 4,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  iconBadge: {
    width: 44,
    height: 44,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
  },
  subtitle: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    marginTop: 2,
  },
  warningBox: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
  },
  warningText: {
    fontFamily: "Inter_500Medium",
    fontSize: 13,
    flex: 1,
    lineHeight: 18,
  },
  sectionLabel: {
    fontFamily: "Inter_500Medium",
    fontSize: 13,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  presets: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  presetBtn: {
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1,
  },
  presetText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
  },
  summary: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    gap: 8,
  },
  summaryRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  summaryLabel: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
  },
  summaryValue: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
  },
  confirmBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 14,
    borderRadius: 14,
    marginTop: 4,
  },
  confirmText: {
    color: "#fff",
    fontFamily: "Inter_700Bold",
    fontSize: 16,
  },
});
